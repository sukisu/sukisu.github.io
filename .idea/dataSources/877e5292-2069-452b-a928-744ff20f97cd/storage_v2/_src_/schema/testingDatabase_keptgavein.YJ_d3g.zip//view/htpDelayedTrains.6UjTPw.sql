create definer = testingDatabase_keptgavein@`%` view htpDelayedTrains as
select `testingDatabase_keptgavein`.`htpOverview`.`trainMetricsKey`    AS `trainMetricsKey`,
       `testingDatabase_keptgavein`.`htpOverview`.`trainDetailsKey`    AS `trainDetailsKey`,
       `testingDatabase_keptgavein`.`htpOverview`.`trainCompanyName`   AS `trainCompanyName`,
       `testingDatabase_keptgavein`.`htpOverview`.`trainDate`          AS `trainDate`,
       `testingDatabase_keptgavein`.`htpOverview`.`scheduledDep`       AS `scheduledDep`,
       `testingDatabase_keptgavein`.`htpOverview`.`fromLocation`       AS `fromLocation`,
       `testingDatabase_keptgavein`.`htpOverview`.`actualDep`          AS `actualDep`,
       `testingDatabase_keptgavein`.`htpOverview`.`scheduledArr`       AS `scheduledArr`,
       `testingDatabase_keptgavein`.`htpOverview`.`toLocation`         AS `toLocation`,
       `testingDatabase_keptgavein`.`htpOverview`.`actualArrival`      AS `actualArrival`,
       `testingDatabase_keptgavein`.`htpOverview`.`cancellation`       AS `cancellation`,
       `testingDatabase_keptgavein`.`htpOverview`.`nextAvailableTrain` AS `nextAvailableTrain`,
       `testingDatabase_keptgavein`.`htpOverview`.`delay_time`         AS `delay_time`
from `testingDatabase_keptgavein`.`htpOverview`
where (`testingDatabase_keptgavein`.`htpOverview`.`delay_time` >= 15);

