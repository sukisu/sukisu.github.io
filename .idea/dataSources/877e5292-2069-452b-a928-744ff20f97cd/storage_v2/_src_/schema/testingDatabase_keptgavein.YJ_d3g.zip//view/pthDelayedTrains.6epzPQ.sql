create definer = testingDatabase_keptgavein@`%` view pthDelayedTrains as
select `testingDatabase_keptgavein`.`pthOverview`.`trainMetricsKey`    AS `trainMetricsKey`,
       `testingDatabase_keptgavein`.`pthOverview`.`trainDetailsKey`    AS `trainDetailsKey`,
       `testingDatabase_keptgavein`.`pthOverview`.`trainCompanyName`   AS `trainCompanyName`,
       `testingDatabase_keptgavein`.`pthOverview`.`trainDate`          AS `trainDate`,
       `testingDatabase_keptgavein`.`pthOverview`.`scheduledDep`       AS `scheduledDep`,
       `testingDatabase_keptgavein`.`pthOverview`.`fromLocation`       AS `fromLocation`,
       `testingDatabase_keptgavein`.`pthOverview`.`actualDep`          AS `actualDep`,
       `testingDatabase_keptgavein`.`pthOverview`.`scheduledArr`       AS `scheduledArr`,
       `testingDatabase_keptgavein`.`pthOverview`.`toLocation`         AS `toLocation`,
       `testingDatabase_keptgavein`.`pthOverview`.`actualArrival`      AS `actualArrival`,
       `testingDatabase_keptgavein`.`pthOverview`.`cancellation`       AS `cancellation`,
       `testingDatabase_keptgavein`.`pthOverview`.`nextAvailableTrain` AS `nextAvailableTrain`,
       `testingDatabase_keptgavein`.`pthOverview`.`delay_time`         AS `delay_time`
from `testingDatabase_keptgavein`.`pthOverview`
where (`testingDatabase_keptgavein`.`pthOverview`.`delay_time` >= 15);

